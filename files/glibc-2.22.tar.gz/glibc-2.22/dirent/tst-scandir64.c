#define D(x) x##64
#include "tst-scandir.c"
