extern int circlemod3 (void);

int
circlemod2 (void)
{
  return circlemod3 ();
}
