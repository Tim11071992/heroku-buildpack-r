#define _FILE_OFFSET_BITS 64
#include "tst-chk2.c"
